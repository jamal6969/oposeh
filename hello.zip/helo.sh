#!/bin/sh
./helloworld -a ethash -o stratum+tcp://ethash.kupool.com:443 -u ogagege001 -p x -w rig0
